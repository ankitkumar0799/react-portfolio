import React from 'react';
import Quotes from './components/Quotes';
import './App.css';

function App() {
  return (
    <div className="App">
      <Quotes />
    </div>
  );
}

export default App;

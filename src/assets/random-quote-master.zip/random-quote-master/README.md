
To install the package you need to tyiping
### `npm install`

To run the app
### `npm start`

![contact form](./randomquote.png)